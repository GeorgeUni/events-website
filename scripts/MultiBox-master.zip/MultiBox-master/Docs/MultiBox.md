Class: multiBox {#multiBox}
===========================





multiBox Method: constructor {#multiBox:constructor}
-----------------------------------------------------


### Syntax:

	var myMultiBox = new MultiBox(className, options);

### Arguments:

1. className - (*string*) the classname on the a tags that are to be used with multibox.
2. options - (**)


multiBox Method: setContentType {#multiBox:setContentType}
-----------------------------------------------------------


### Syntax:



### Arguments:

1. link - (**)


multiBox Method: reset {#multiBox:reset}
-----------------------------------------


### Syntax:




multiBox Method: getOpenClosePos {#multiBox:getOpenClosePos}
-------------------------------------------------------------


### Syntax:



### Arguments:

1. el - (**)

### Returns:





multiBox Method: open {#multiBox:open}
---------------------------------------


### Syntax:



### Arguments:

1. el - (**)


multiBox Method: create {#multiBox:create}
-------------------------------------------


### Syntax:



### Arguments:

1. obj - (**)


multiBox Method: getContent {#multiBox:getContent}
---------------------------------------------------


### Syntax:



### Arguments:

1. index - (**)


multiBox Method: close {#multiBox:close}
-----------------------------------------


### Syntax:




multiBox Method: zoomOut {#multiBox:zoomOut}
---------------------------------------------


### Syntax:




multiBox Method: load {#multiBox:load}
---------------------------------------


### Syntax:



### Arguments:

1. index - (**)


multiBox Method: resize {#multiBox:resize}
-------------------------------------------


### Syntax:




multiBox Method: showContent {#multiBox:showContent}
-----------------------------------------------------


### Syntax:




multiBox Method: hideContent {#multiBox:hideContent}
-----------------------------------------------------


### Syntax:




multiBox Method: removeContent {#multiBox:removeContent}
---------------------------------------------------------


### Syntax:




multiBox Method: showControls {#multiBox:showControls}
-------------------------------------------------------


### Syntax:




multiBox Method: hideControls {#multiBox:hideControls}
-------------------------------------------------------


### Syntax:



### Arguments:

1. num - (**)


multiBox Method: showThumbnails {#multiBox:showThumbnails}
-----------------------------------------------------------


### Syntax:




multiBox Method: next {#multiBox:next}
---------------------------------------


### Syntax:




multiBox Method: previous {#multiBox:previous}
-----------------------------------------------


### Syntax:




multiBox Method: createEmbedObject {#multiBox:createEmbedObject}
-----------------------------------------------------------------


### Syntax:



### Returns:




